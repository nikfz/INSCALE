﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;
using System.Data.SqlClient;
using System.Data;

namespace DataAccess
{
    public class User: IUser
    {

        private string connString;

        public User(string conStr)
        {
            connString = conStr;
        }

       public bool Authenticate(string username, string password)
        {
            bool valid = false;

            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(connString))
            using (SqlCommand cmd = new SqlCommand("spAuthenticateUser", conn))
            {
                SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                adapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                adapt.SelectCommand.Parameters.Add(new SqlParameter("@UserName", SqlDbType.VarChar, 50));
                adapt.SelectCommand.Parameters["@UserName"].Value = username;
                adapt.SelectCommand.Parameters.Add(new SqlParameter("@Password", SqlDbType.VarChar, 50));
                adapt.SelectCommand.Parameters["@Password"].Value = password;
                adapt.Fill(dt);
            }

            if (dt.Rows.Count > 0)
            {
                valid = true;
            }
            return valid;
        }

        public bool CreateUser(UserProfile user)
        {
            bool result = false;

            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                using (SqlCommand cmd = new SqlCommand("spAddUser", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@UserName", SqlDbType.VarChar, 50));
                    cmd.Parameters["@UserName"].Value = user.UserName;
                    cmd.Parameters.Add(new SqlParameter("@Password", SqlDbType.VarChar, 50));
                    cmd.Parameters["@Password"].Value = user.Password;
                    cmd.Parameters.Add(new SqlParameter("@Name", SqlDbType.VarChar, 10));
                    cmd.Parameters["@Name"].Value = user.Name;
                    cmd.Parameters.Add(new SqlParameter("@Gender", SqlDbType.Bit));
                    cmd.Parameters["@Gender"].Value = (user.Gender == "Male") ? "False" : "True";
                    cmd.Parameters.Add(new SqlParameter("@DOB", SqlDbType.Date));
                    cmd.Parameters["@DOB"].Value = user.DOB;
                    cmd.Parameters.Add(new SqlParameter("@CountryId", SqlDbType.Int));
                    cmd.Parameters["@CountryId"].Value = user.CountryId ;

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    result = true;
                }
            }
            catch (Exception ex)
            {
                //throw ex;
                //log exception
            }
            return result;
        }

        public bool DeleteUser(string userName)
        {
            bool result = false;

            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                using (SqlCommand cmd = new SqlCommand("spDeleteUser", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@UserName", SqlDbType.VarChar, 50));
                    cmd.Parameters["@UserName"].Value = userName;

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    result = true;
                }
            }
            catch (Exception ex)
            {
                //throw ex;
                //log exception
            }
            return result;
        }

        public Entity.UserProfile GetUser(string userName)
        {
            Entity.UserProfile user = new Entity.UserProfile();
            DataTable dt = new DataTable();

            using (SqlConnection conn = new SqlConnection(connString))
            using (SqlCommand cmd = new SqlCommand("spGetUserByLogin", conn))
            {
                SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                adapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                adapt.SelectCommand.Parameters.Add(new SqlParameter("@UserName", SqlDbType.VarChar, 50));
                adapt.SelectCommand.Parameters["@UserName"].Value = userName;
                adapt.Fill(dt);
            }

            if (dt.Rows.Count > 0)
            {
                user.UserName = dt.Rows[0]["UserName"].ToString();
                user.UserType = dt.Rows[0]["UserType"].ToString();
                user.Name = dt.Rows[0]["Name"].ToString();
                user.Gender = (dt.Rows[0]["Gender"].ToString() == "False") ? "Male" : "Female";
                user.DOB = DateTime.Parse(dt.Rows[0]["DOB"].ToString());
                user.Country = dt.Rows[0]["CountryName"].ToString();
            }
            return user;
        }

        public List<UserProfile> GetUsers()
        {
            List<UserProfile> users = new List<UserProfile>();
            DataTable dt = new DataTable();

            using (SqlConnection conn = new SqlConnection(connString))
            using (SqlCommand cmd = new SqlCommand("spGetUsers", conn))
            {
                SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                adapt.SelectCommand.CommandType = CommandType.StoredProcedure;
                adapt.Fill(dt);
            }

            foreach (DataRow row in dt.Rows)
            {
                UserProfile user = new UserProfile();
                user.UserName = row["UserName"].ToString();
                user.UserType = row["UserType"].ToString();
                user.Name = row["Name"].ToString();
                user.DOB = DateTime.Parse(row["DOB"].ToString());
                user.Gender = (row["Gender"].ToString() == "False")? "Male" : "Female";
                user.Country = row["CountryName"].ToString();
                users.Add(user);
            }

            return users;
        }
    }
}
