﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{
    public interface IUser
    {

        bool Authenticate(string user, string password);

        Entity.UserProfile GetUser(string userName);

        List<Entity.UserProfile> GetUsers();

        bool CreateUser(Entity.UserProfile user);

        bool DeleteUser(string userName);

    }
}
