﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WcfService
{
    [ServiceContract]
    public interface IUser
    {
        [OperationContract]
        string Hello();

        [OperationContract]
        bool Authenticate(string userName, string password);

        [OperationContract]
        Entity.UserProfile GetUserProfile(string userName);

        [OperationContract]
        List<Entity.UserProfile> GetUserList();

        [OperationContract]
        bool CreateUser(Entity.UserProfile user);

        [OperationContract]
        bool DeleteUser(string userName);

    }
}
