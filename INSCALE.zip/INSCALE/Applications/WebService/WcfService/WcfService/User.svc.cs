﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using Entity;

namespace WcfService
{
    public class User : IUser
    {

        private string ConnString
        {
            get
            {
                return System.Configuration.ConfigurationManager.ConnectionStrings["server1"].ConnectionString;
            }
        }

        public bool Authenticate(string userName, string password)
        {
            DataAccess.IUser dat = new DataAccess.User(ConnString);
            return dat.Authenticate(userName, password);
        }

        public bool CreateUser(UserProfile user)
        {
            DataAccess.IUser dat = new DataAccess.User(ConnString);
            return dat.CreateUser(user);
        }

        public bool DeleteUser(string userName)
        {
            DataAccess.IUser dat = new DataAccess.User(ConnString);
            return dat.DeleteUser(userName);
        }

        public List<UserProfile> GetUserList()
        {
            List<UserProfile> users = new List<UserProfile>();
            DataAccess.IUser dat = new DataAccess.User(ConnString);
            users = dat.GetUsers();
            return users;
        }

        public UserProfile GetUserProfile(string userName)
        {
            DataAccess.IUser dat = new DataAccess.User(ConnString);
            Entity.UserProfile user = dat.GetUser(userName);
            return user;
        }

        public string  Hello()
        {
            return "Hello";
        }



    }
}
