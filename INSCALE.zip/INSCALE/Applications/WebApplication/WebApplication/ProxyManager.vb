﻿Public Class ProxyManager

    Private Shared _proxy As ServiceReference.UserClient

    Public Shared Function GetCurrentProxy() As ServiceReference.UserClient
        If _proxy Is Nothing Then
            _proxy = New ServiceReference.UserClient
            _proxy.ClientCredentials.UserName.UserName = "WebApp"
            _proxy.ClientCredentials.UserName.Password = "P@ssw0rd"
        End If
        Return _proxy
    End Function

End Class
