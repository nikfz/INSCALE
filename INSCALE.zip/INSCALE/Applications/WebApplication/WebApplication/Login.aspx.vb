﻿Imports System.Web.Security

Public Class Login
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click

        Dim proxy As New ServiceReference.UserClient()
        Dim authenticated As Boolean = False

        Try
            authenticated = proxy.Authenticate(txtUser.Text, txtPassword.Text)
        Catch ex As Exception
        End Try

        If authenticated Then
            lblError.Text = String.Empty
            Dim user As Entity.UserProfile
            user = proxy.GetUserProfile(txtUser.Text)
            If user IsNot Nothing Then
                Session("UserProfile") = user
                FormsAuthentication.SetAuthCookie(user.UserName, True)
                Response.Redirect("~\Pages\Main.aspx")
            End If
        Else
            lblError.Text = "Invalid Login"
        End If
    End Sub

End Class