﻿Public Class UserProfile
    Inherits System.Web.UI.Page

    Private Property UserProfile As Entity.UserProfile
        Get
            If Session("UserProfile") Is Nothing Then
                Return Nothing
            End If
            Return DirectCast(Session("UserProfile"), Entity.UserProfile)
        End Get
        Set(value As Entity.UserProfile)
            Session("UserProfile") = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Dim mode As String = Request.QueryString("mode")
            BuildUI(mode)
        End If
    End Sub

    Private Sub BuildUI(mode As String)
        LoadGender()
        LoadCountry()
        If mode = "add" Then
            lblTitle.Text = "Create User"
        Else
            lblTitle.Text = "My Profile"
            trPassword.Visible = False
            trUserName.Visible = False
            txtName.ReadOnly = True
            drpGender.Enabled = False
            drpCountry.Enabled = False
            btnSave.Visible = False
            LoadData()
        End If
    End Sub

    Private Sub LoadData()
        With UserProfile
            txtName.Text = .Name
            drpGender.SelectedItem.Text = .Gender
            drpCountry.SelectedItem.Text = .Country
        End With
    End Sub

    Private Sub LoadGender()
        Dim gender As New Dictionary(Of String, String)
        gender.Add("0", "Male")
        gender.Add("1", "Female")
        drpGender.DataSource = gender
        drpGender.DataValueField = "Key"
        drpGender.DataTextField = "Value"
        drpGender.DataBind()
    End Sub

    Private Sub LoadCountry()
        Dim country As New Dictionary(Of String, String)
        country.Add("1", "Malaysia")
        country.Add("2", "Brunei")
        country.Add("3", "Indonesia")
        country.Add("4", "Singapore")
        drpCountry.DataSource = country
        drpCountry.DataValueField="Key"
        drpCountry.DataTextField = "Value"
        drpCountry.DataBind()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Dim user As New Entity.UserProfile
        With user
            .UserName = txtUser.Text
            .Password = txtPassword.Text
            .Name = txtName.Text
            .Gender = drpGender.SelectedItem.Text
            .DOB = New Date(1977, 2, 3)
            .CountryId = Convert.ToInt16(drpCountry.SelectedValue)
        End With

        Dim proxy As New ServiceReference.UserClient()
        Try
            If proxy.CreateUser(user) Then
                Response.Redirect("~\Pages\UserList.aspx")
            End If
        Catch ex As Exception
            lblError.Text = ex.Message
        End Try
    End Sub

End Class