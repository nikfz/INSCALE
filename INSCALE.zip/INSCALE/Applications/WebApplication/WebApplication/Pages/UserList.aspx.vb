﻿Public Class UserList
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        LoadData()
    End Sub

    Private Sub LoadData()
        Dim proxy = ProxyManager.GetCurrentProxy
        Try
            Dim users As Entity.UserProfile()
            users = proxy.GetUserList

            GridView1.DataSource = users
            GridView1.DataBind()
        Catch ex As Exception
            lblError.Text = ex.Message
        End Try
    End Sub

    Private Sub GridView1_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridView1.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim name As String = e.Row.Cells(0).Text
            If name = "admin" Then
                For Each button As LinkButton In e.Row.Cells(4).Controls.OfType(Of LinkButton)()
                    button.Visible = False
                Next
            End If
        End If
    End Sub

    Private Sub GridView1_RowDeleting(sender As Object, e As GridViewDeleteEventArgs) Handles GridView1.RowDeleting
        Dim index As Integer = Convert.ToInt32(e.RowIndex)
        Dim loginName As String = GridView1.Rows(index).Cells(0).Text
        Dim proxy = ProxyManager.GetCurrentProxy
        Try
            If proxy.DeleteUser(loginName) Then
                LoadData()
            End If
        Catch ex As Exception
            lblError.Text = ex.Message
        End Try
    End Sub
End Class