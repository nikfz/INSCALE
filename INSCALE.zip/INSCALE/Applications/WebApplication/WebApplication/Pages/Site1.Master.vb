﻿Public Class Site1
    Inherits System.Web.UI.MasterPage

    Private Property UserProfile As Entity.UserProfile
        Get
            If Session("UserProfile") Is Nothing Then
                Return Nothing
            End If
            Return DirectCast(Session("UserProfile"), Entity.UserProfile)
        End Get
        Set(value As Entity.UserProfile)
            Session("UserProfile") = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If UserProfile IsNot Nothing AndAlso UserProfile.UserType = "admin" Then
            lnkCreateUser.Visible = True
            lnkUserList.Visible = True
        Else
            lnkCreateUser.Visible = False
            lnkUserList.Visible = False
        End If
    End Sub

    Private Sub lnkCreateUser_Click(sender As Object, e As EventArgs) Handles lnkCreateUser.Click
        Response.Redirect("~\Pages\UserProfile.aspx?mode=add")
    End Sub

    Private Sub lnkHome_Click(sender As Object, e As EventArgs) Handles lnkHome.Click
        Response.Redirect("~\Pages\Main.aspx")
    End Sub

    Private Sub lnkLogout_Click(sender As Object, e As EventArgs) Handles lnkLogout.Click
        UserProfile = Nothing
        FormsAuthentication.SignOut()
        Response.Redirect("~\Login.aspx")
    End Sub

    Private Sub lnkMyProfile_Click(sender As Object, e As EventArgs) Handles lnkMyProfile.Click
        Response.Redirect("~\Pages\UserProfile.aspx?mode=view")
    End Sub

    Private Sub lnkUserList_Click(sender As Object, e As EventArgs) Handles lnkUserList.Click
        Response.Redirect("~\Pages\UserList.aspx")
    End Sub
End Class